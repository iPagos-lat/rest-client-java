
# GetAllSubscriptionsResponsePlanInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | Plan code  |  [optional]
**name** | **String** | Plan name  |  [optional]
**billingPeriod** | [**GetAllPlansResponsePlanInformationBillingPeriod**](GetAllPlansResponsePlanInformationBillingPeriod.md) |  |  [optional]
**billingCycles** | [**GetAllSubscriptionsResponsePlanInformationBillingCycles**](GetAllSubscriptionsResponsePlanInformationBillingCycles.md) |  |  [optional]



