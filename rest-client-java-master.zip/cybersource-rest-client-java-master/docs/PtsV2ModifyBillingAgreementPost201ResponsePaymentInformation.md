
# PtsV2ModifyBillingAgreementPost201ResponsePaymentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eWallet** | [**PtsV2ModifyBillingAgreementPost201ResponsePaymentInformationEWallet**](PtsV2ModifyBillingAgreementPost201ResponsePaymentInformationEWallet.md) |  |  [optional]
**bank** | [**PtsV2ModifyBillingAgreementPost201ResponsePaymentInformationBank**](PtsV2ModifyBillingAgreementPost201ResponsePaymentInformationBank.md) |  |  [optional]



