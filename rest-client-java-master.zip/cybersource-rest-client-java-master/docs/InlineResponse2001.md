
# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**registrationInformation** | [**Boardingv1registrationsRegistrationInformation**](Boardingv1registrationsRegistrationInformation.md) |  |  [optional]
**integrationInformation** | [**InlineResponse2001IntegrationInformation**](InlineResponse2001IntegrationInformation.md) |  |  [optional]
**organizationInformation** | [**Boardingv1registrationsOrganizationInformation**](Boardingv1registrationsOrganizationInformation.md) |  |  [optional]
**productInformation** | [**Boardingv1registrationsProductInformation**](Boardingv1registrationsProductInformation.md) |  |  [optional]
**productInformationSetups** | [**List&lt;InlineResponse2012ProductInformationSetups&gt;**](InlineResponse2012ProductInformationSetups.md) |  |  [optional]
**documentInformation** | [**Boardingv1registrationsDocumentInformation**](Boardingv1registrationsDocumentInformation.md) |  |  [optional]
**details** | [**Map&lt;String, List&lt;Object&gt;&gt;**](List.md) |  |  [optional]



