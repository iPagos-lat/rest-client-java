
# PtsV2PaymentsPost201Response1OrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billTo** | [**PtsV2PaymentsPost201Response1OrderInformationBillTo**](PtsV2PaymentsPost201Response1OrderInformationBillTo.md) |  |  [optional]
**shipTo** | [**PtsV2PaymentsPost201Response1OrderInformationShipTo**](PtsV2PaymentsPost201Response1OrderInformationShipTo.md) |  |  [optional]



