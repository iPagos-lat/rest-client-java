
# InlineResponse4006Details

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** | This is the flattened JSON object field name/path that is either missing or invalid. |  [optional]
**reason** | **String** | Possible reasons for the error. |  [optional]



