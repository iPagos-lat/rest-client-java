
# PaymentInstrumentList1EmbeddedEmbedded

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumentIdentifier** | [**PatchInstrumentIdentifierRequest**](PatchInstrumentIdentifierRequest.md) |  |  [optional]



