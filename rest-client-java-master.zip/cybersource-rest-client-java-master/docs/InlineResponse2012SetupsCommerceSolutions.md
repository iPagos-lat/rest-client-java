
# InlineResponse2012SetupsCommerceSolutions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tokenManagement** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**accountUpdater** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**binLookup** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]



