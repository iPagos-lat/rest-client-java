
# InlineResponseDefaultLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**next** | [**List&lt;InlineResponseDefaultLinksNext&gt;**](InlineResponseDefaultLinksNext.md) |  |  [optional]
**documentation** | [**List&lt;InlineResponseDefaultLinksNext&gt;**](InlineResponseDefaultLinksNext.md) |  |  [optional]
**self** | [**InlineResponseDefaultLinksNext**](InlineResponseDefaultLinksNext.md) |  |  [optional]



