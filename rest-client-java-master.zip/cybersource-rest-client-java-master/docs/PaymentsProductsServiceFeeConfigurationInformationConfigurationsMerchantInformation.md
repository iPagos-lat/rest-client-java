
# PaymentsProductsServiceFeeConfigurationInformationConfigurationsMerchantInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the merchant account. |  [optional]
**contact** | **String** | Phone number of the primary contact for the merchant account. |  [optional]
**state** | **String** | 2-character ISO code for the U.S. state in which the merchant is registered |  [optional]



