
# PaymentInstrumentListLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**PaymentInstrumentListLinksSelf**](PaymentInstrumentListLinksSelf.md) |  |  [optional]
**first** | [**PaymentInstrumentListLinksFirst**](PaymentInstrumentListLinksFirst.md) |  |  [optional]
**prev** | [**PaymentInstrumentListLinksPrev**](PaymentInstrumentListLinksPrev.md) |  |  [optional]
**next** | [**PaymentInstrumentListLinksNext**](PaymentInstrumentListLinksNext.md) |  |  [optional]
**last** | [**PaymentInstrumentListLinksLast**](PaymentInstrumentListLinksLast.md) |  |  [optional]



