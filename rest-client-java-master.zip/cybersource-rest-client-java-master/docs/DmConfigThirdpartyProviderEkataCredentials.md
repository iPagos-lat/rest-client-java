
# DmConfigThirdpartyProviderEkataCredentials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**apiKey** | **String** |  |  [optional]



