
# PtsV2IncrementalAuthorizationPatch201ResponsePaymentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountFeatures** | [**PtsV2IncrementalAuthorizationPatch201ResponsePaymentInformationAccountFeatures**](PtsV2IncrementalAuthorizationPatch201ResponsePaymentInformationAccountFeatures.md) |  |  [optional]



