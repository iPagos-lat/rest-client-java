
# GetAllSubscriptionsResponseOrderInformationBillTo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** | Customer&#39;s first name.  |  [optional]
**lastName** | **String** | Customer&#39;s last name.  |  [optional]



