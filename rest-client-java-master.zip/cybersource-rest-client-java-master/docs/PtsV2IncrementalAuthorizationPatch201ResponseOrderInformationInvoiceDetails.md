
# PtsV2IncrementalAuthorizationPatch201ResponseOrderInformationInvoiceDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productId** | **String** | Product identifier code. Also known as the Stock Keeping Unit (SKU) code for the product.  |  [optional]



