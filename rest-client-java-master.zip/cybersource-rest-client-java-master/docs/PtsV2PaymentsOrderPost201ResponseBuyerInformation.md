
# PtsV2PaymentsOrderPost201ResponseBuyerInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**personalIdentification** | [**List&lt;PtsV2PaymentsOrderPost201ResponseBuyerInformationPersonalIdentification&gt;**](PtsV2PaymentsOrderPost201ResponseBuyerInformationPersonalIdentification.md) |  |  [optional]



