
# InlineResponseDefaultLinksNext

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | URI of the linked resource. |  [optional]
**title** | **String** | Label of the linked resource. |  [optional]
**method** | **String** | HTTP method of the linked resource. |  [optional]



