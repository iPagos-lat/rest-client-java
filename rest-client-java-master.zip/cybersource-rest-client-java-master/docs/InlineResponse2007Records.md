
# InlineResponse2007Records

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**sourceRecord** | [**InlineResponse2007SourceRecord**](InlineResponse2007SourceRecord.md) |  |  [optional]
**responseRecord** | [**InlineResponse2007ResponseRecord**](InlineResponse2007ResponseRecord.md) |  |  [optional]



