
# Accountupdaterv1batchesIncludedTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**expirationMonth** | **String** |  |  [optional]
**expirationYear** | **String** |  |  [optional]



