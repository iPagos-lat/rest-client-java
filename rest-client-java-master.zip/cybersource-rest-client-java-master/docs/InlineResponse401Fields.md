
# InlineResponse401Fields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**localizationKey** | **String** | Valid Values:   * cybsapi.ondemand.batch.email.null  |  [optional]



