
# InlineResponse202

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**InlineResponse202Links**](InlineResponse202Links.md) |  |  [optional]
**batchId** | **String** | Unique identification number assigned to the submitted request. |  [optional]
**batchItemCount** | **Integer** |  |  [optional]



