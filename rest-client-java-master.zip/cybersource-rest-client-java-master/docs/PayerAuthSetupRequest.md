
# PayerAuthSetupRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Riskv1authenticationsetupsClientReferenceInformation**](Riskv1authenticationsetupsClientReferenceInformation.md) |  |  [optional]
**paymentInformation** | [**Riskv1authenticationsetupsPaymentInformation**](Riskv1authenticationsetupsPaymentInformation.md) |  |  [optional]
**processingInformation** | [**Riskv1authenticationsetupsProcessingInformation**](Riskv1authenticationsetupsProcessingInformation.md) |  |  [optional]
**tokenInformation** | [**Riskv1authenticationsetupsTokenInformation**](Riskv1authenticationsetupsTokenInformation.md) |  |  [optional]



