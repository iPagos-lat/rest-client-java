
# PostRegistrationBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**registrationInformation** | [**Boardingv1registrationsRegistrationInformation**](Boardingv1registrationsRegistrationInformation.md) |  |  [optional]
**integrationInformation** | [**Boardingv1registrationsIntegrationInformation**](Boardingv1registrationsIntegrationInformation.md) |  |  [optional]
**organizationInformation** | [**Boardingv1registrationsOrganizationInformation**](Boardingv1registrationsOrganizationInformation.md) |  | 
**productInformation** | [**Boardingv1registrationsProductInformation**](Boardingv1registrationsProductInformation.md) |  |  [optional]
**documentInformation** | [**Boardingv1registrationsDocumentInformation**](Boardingv1registrationsDocumentInformation.md) |  |  [optional]



