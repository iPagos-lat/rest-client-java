
# PaymentsProductsServiceFee

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsPayerAuthenticationSubscriptionInformation**](PaymentsProductsPayerAuthenticationSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsServiceFeeConfigurationInformation**](PaymentsProductsServiceFeeConfigurationInformation.md) |  |  [optional]



