
# InlineResponse2005Embedded

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**batches** | [**List&lt;InlineResponse2005EmbeddedBatches&gt;**](InlineResponse2005EmbeddedBatches.md) |  |  [optional]



