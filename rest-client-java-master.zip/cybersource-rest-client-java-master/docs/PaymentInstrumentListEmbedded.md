
# PaymentInstrumentListEmbedded

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paymentInstruments** | [**List&lt;Tmsv2customersEmbeddedDefaultPaymentInstrument&gt;**](Tmsv2customersEmbeddedDefaultPaymentInstrument.md) |  |  [optional]



