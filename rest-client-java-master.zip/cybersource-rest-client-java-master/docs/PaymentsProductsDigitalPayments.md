
# PaymentsProductsDigitalPayments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsDigitalPaymentsSubscriptionInformation**](PaymentsProductsDigitalPaymentsSubscriptionInformation.md) |  |  [optional]



