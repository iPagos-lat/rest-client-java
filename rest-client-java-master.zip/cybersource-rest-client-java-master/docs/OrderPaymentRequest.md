
# OrderPaymentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**PtsV2IncrementalAuthorizationPatch201ResponseClientReferenceInformation**](PtsV2IncrementalAuthorizationPatch201ResponseClientReferenceInformation.md) |  |  [optional]
**processingInformation** | [**Ptsv2paymentreferencesidintentsProcessingInformation**](Ptsv2paymentreferencesidintentsProcessingInformation.md) |  |  [optional]
**paymentInformation** | [**Ptsv2paymentreferencesidintentsPaymentInformation**](Ptsv2paymentreferencesidintentsPaymentInformation.md) |  |  [optional]
**orderInformation** | [**Ptsv2paymentreferencesidintentsOrderInformation**](Ptsv2paymentreferencesidintentsOrderInformation.md) |  |  [optional]



