
# InlineResponse410

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;InlineResponse410Errors&gt;**](InlineResponse410Errors.md) |  |  [optional]



