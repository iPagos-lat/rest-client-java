
# Flexv2sessionsFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderInformation** | [**Flexv2sessionsFieldsOrderInformation**](Flexv2sessionsFieldsOrderInformation.md) |  |  [optional]
**paymentInformation** | [**Flexv2sessionsFieldsPaymentInformation**](Flexv2sessionsFieldsPaymentInformation.md) |  |  [optional]



