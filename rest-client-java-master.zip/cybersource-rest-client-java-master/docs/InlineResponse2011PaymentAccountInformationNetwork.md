
# InlineResponse2011PaymentAccountInformationNetwork

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | This field contains a code that identifies the network. [List of Network ID and Sharing Group Code](https://developer.visa.com/request_response_codes#network_id_and_sharing_group_code)  |  [optional]



