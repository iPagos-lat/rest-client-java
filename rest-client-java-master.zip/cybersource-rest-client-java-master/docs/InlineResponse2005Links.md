
# InlineResponse2005Links

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rel** | **String** | Valid Values:   * self   * first   * last   * prev   * next  |  [optional]
**href** | **String** |  |  [optional]



