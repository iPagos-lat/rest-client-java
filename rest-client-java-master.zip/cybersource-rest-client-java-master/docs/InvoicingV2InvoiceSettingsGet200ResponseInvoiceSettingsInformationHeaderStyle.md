
# InvoicingV2InvoiceSettingsGet200ResponseInvoiceSettingsInformationHeaderStyle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fontColor** | **String** | The invoice font color. The format is a valid hexadecimal code prefixed with &#x60;#&#x60;, such as &#x60;#000000&#x60; for black. |  [optional]
**backgroundColor** | **String** | The invoice background color. The format is a valid hexadecimal code prefixed with &#x60;#&#x60;, such as &#x60;#ffffff&#x60; for white. |  [optional]



