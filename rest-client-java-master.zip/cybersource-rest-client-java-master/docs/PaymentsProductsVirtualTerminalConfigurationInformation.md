
# PaymentsProductsVirtualTerminalConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templateId** | [**UUID**](UUID.md) |  |  [optional]
**configurations** | [**VTConfig**](VTConfig.md) |  |  [optional]



