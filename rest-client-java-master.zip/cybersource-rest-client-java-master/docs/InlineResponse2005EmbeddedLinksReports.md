
# InlineResponse2005EmbeddedLinksReports

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** |  |  [optional]



