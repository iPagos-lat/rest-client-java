
# PaymentInstrumentListLinksSelf

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | Link to the current page.  |  [optional]



