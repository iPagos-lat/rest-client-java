
# InlineResponse200Embedded

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capture** | [**InlineResponse200EmbeddedCapture**](InlineResponse200EmbeddedCapture.md) |  |  [optional]
**reversal** | [**InlineResponse200EmbeddedReversal**](InlineResponse200EmbeddedReversal.md) |  |  [optional]



