
# GetAllPlansResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**GetAllPlansResponseOrderInformationAmountDetails**](GetAllPlansResponseOrderInformationAmountDetails.md) |  |  [optional]



