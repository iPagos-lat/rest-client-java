
# Boardingv1registrationsIntegrationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oauth2** | [**List&lt;Boardingv1registrationsIntegrationInformationOauth2&gt;**](Boardingv1registrationsIntegrationInformationOauth2.md) |  |  [optional]
**tenantConfigurations** | [**List&lt;Boardingv1registrationsIntegrationInformationTenantConfigurations&gt;**](Boardingv1registrationsIntegrationInformationTenantConfigurations.md) | tenantConfigurations is an array of objects that includes the tenant information this merchant is associated with. |  [optional]



