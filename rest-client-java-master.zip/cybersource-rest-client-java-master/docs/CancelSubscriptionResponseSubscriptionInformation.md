
# CancelSubscriptionResponseSubscriptionInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | Subscription code.  |  [optional]
**status** | **String** | Subscription Status: - &#x60;CANCELLED&#x60;  |  [optional]



