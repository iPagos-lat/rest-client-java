
# InlineResponse200EmbeddedCaptureLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**InlineResponse200EmbeddedCaptureLinksSelf**](InlineResponse200EmbeddedCaptureLinksSelf.md) |  |  [optional]



