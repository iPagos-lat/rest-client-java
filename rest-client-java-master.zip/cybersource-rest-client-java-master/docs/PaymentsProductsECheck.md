
# PaymentsProductsECheck

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsECheckSubscriptionInformation**](PaymentsProductsECheckSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsECheckConfigurationInformation**](PaymentsProductsECheckConfigurationInformation.md) |  |  [optional]



