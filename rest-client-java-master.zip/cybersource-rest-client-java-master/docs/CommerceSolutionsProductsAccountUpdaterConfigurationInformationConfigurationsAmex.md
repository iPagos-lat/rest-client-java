
# CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsAmex

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mode** | **String** | Type of mode. Valid values are &#x60;tokenApi&#x60; or &#x60;dailyHarvest&#x60;. |  [optional]
**seNumber** | **String** |  |  [optional]
**subscriberId** | **String** |  |  [optional]
**active** | **Boolean** |  |  [optional]



