
# OctCreatePaymentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Ptsv2payoutsClientReferenceInformation**](Ptsv2payoutsClientReferenceInformation.md) |  |  [optional]
**orderInformation** | [**Ptsv2payoutsOrderInformation**](Ptsv2payoutsOrderInformation.md) |  |  [optional]
**merchantInformation** | [**Ptsv2payoutsMerchantInformation**](Ptsv2payoutsMerchantInformation.md) |  |  [optional]
**recipientInformation** | [**Ptsv2payoutsRecipientInformation**](Ptsv2payoutsRecipientInformation.md) |  |  [optional]
**senderInformation** | [**Ptsv2payoutsSenderInformation**](Ptsv2payoutsSenderInformation.md) |  |  [optional]
**processingInformation** | [**Ptsv2payoutsProcessingInformation**](Ptsv2payoutsProcessingInformation.md) |  |  [optional]
**paymentInformation** | [**Ptsv2payoutsPaymentInformation**](Ptsv2payoutsPaymentInformation.md) |  |  [optional]



