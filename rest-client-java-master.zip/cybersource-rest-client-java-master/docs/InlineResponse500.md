
# InlineResponse500

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;InlineResponse500Errors&gt;**](InlineResponse500Errors.md) |  |  [optional]



