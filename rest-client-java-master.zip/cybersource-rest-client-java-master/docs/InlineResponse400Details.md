
# InlineResponse400Details

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The name of the field that caused the error. |  [optional]
**location** | **String** | The location of the field that caused the error. |  [optional]



