
# AddNegativeListRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderInformation** | [**Riskv1liststypeentriesOrderInformation**](Riskv1liststypeentriesOrderInformation.md) |  |  [optional]
**paymentInformation** | [**Riskv1liststypeentriesPaymentInformation**](Riskv1liststypeentriesPaymentInformation.md) |  |  [optional]
**clientReferenceInformation** | [**Riskv1liststypeentriesClientReferenceInformation**](Riskv1liststypeentriesClientReferenceInformation.md) |  |  [optional]
**deviceInformation** | [**Riskv1liststypeentriesDeviceInformation**](Riskv1liststypeentriesDeviceInformation.md) |  |  [optional]
**riskInformation** | [**Riskv1liststypeentriesRiskInformation**](Riskv1liststypeentriesRiskInformation.md) |  |  [optional]
**buyerInformation** | [**Riskv1liststypeentriesBuyerInformation**](Riskv1liststypeentriesBuyerInformation.md) |  |  [optional]



