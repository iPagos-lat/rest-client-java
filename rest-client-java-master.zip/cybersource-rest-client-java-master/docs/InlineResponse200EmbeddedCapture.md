
# InlineResponse200EmbeddedCapture

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | The status of the capture if the capture is called.  |  [optional]
**links** | [**InlineResponse200EmbeddedCaptureLinks**](InlineResponse200EmbeddedCaptureLinks.md) |  |  [optional]



