
# InlineResponse200EmbeddedCaptureLinksSelf

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | This is the endpoint of the resource that was created by the successful request.  |  [optional]
**method** | **String** | This refers to the HTTP method that you can send to the self endpoint to retrieve details of the resource.  |  [optional]



