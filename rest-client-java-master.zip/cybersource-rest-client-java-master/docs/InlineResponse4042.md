
# InlineResponse4042

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**details** | [**List&lt;InlineResponse4042Details&gt;**](InlineResponse4042Details.md) |  |  [optional]



