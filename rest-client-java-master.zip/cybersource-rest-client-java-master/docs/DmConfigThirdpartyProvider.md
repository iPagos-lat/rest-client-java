
# DmConfigThirdpartyProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accurint** | [**DmConfigThirdpartyProviderAccurint**](DmConfigThirdpartyProviderAccurint.md) |  |  [optional]
**credilink** | [**DmConfigThirdpartyProviderCredilink**](DmConfigThirdpartyProviderCredilink.md) |  |  [optional]
**ekata** | [**DmConfigThirdpartyProviderEkata**](DmConfigThirdpartyProviderEkata.md) |  |  [optional]
**emailage** | [**DmConfigThirdpartyProviderEmailage**](DmConfigThirdpartyProviderEmailage.md) |  |  [optional]
**perseuss** | [**DmConfigThirdpartyProviderPerseuss**](DmConfigThirdpartyProviderPerseuss.md) |  |  [optional]
**signifyd** | [**DmConfigThirdpartyProviderSignifyd**](DmConfigThirdpartyProviderSignifyd.md) |  |  [optional]
**targus** | [**DmConfigThirdpartyProviderTargus**](DmConfigThirdpartyProviderTargus.md) |  |  [optional]



