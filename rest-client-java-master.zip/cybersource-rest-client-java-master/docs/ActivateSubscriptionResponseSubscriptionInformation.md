
# ActivateSubscriptionResponseSubscriptionInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | Subscription code.  |  [optional]
**status** | **String** | Subscription Status: - &#x60;ACTIVE&#x60;  |  [optional]



