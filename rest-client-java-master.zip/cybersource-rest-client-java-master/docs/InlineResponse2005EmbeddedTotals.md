
# InlineResponse2005EmbeddedTotals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acceptedRecords** | **Integer** |  |  [optional]
**rejectedRecords** | **Integer** |  |  [optional]
**updatedRecords** | **Integer** |  |  [optional]
**caResponses** | **Integer** |  |  [optional]
**caResponsesOmitted** | **Integer** |  |  [optional]



