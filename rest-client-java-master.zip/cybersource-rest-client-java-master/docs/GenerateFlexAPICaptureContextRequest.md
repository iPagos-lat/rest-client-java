
# GenerateFlexAPICaptureContextRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fields** | [**Flexv2sessionsFields**](Flexv2sessionsFields.md) |  |  [optional]



