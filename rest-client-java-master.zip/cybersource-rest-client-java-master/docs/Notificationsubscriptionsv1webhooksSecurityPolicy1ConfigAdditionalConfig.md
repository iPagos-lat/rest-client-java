
# Notificationsubscriptionsv1webhooksSecurityPolicy1ConfigAdditionalConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aud** | **String** |  |  [optional]
**clientId** | **String** |  |  [optional]
**keyId** | **String** |  |  [optional]
**scope** | **String** |  |  [optional]



