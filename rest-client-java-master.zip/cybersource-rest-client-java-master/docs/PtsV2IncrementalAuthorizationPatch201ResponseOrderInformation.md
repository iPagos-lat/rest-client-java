
# PtsV2IncrementalAuthorizationPatch201ResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**PtsV2PaymentsPost201ResponseOrderInformationAmountDetails**](PtsV2PaymentsPost201ResponseOrderInformationAmountDetails.md) |  |  [optional]
**invoiceDetails** | [**PtsV2IncrementalAuthorizationPatch201ResponseOrderInformationInvoiceDetails**](PtsV2IncrementalAuthorizationPatch201ResponseOrderInformationInvoiceDetails.md) |  |  [optional]



