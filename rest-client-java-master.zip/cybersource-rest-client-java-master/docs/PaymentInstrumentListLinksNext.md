
# PaymentInstrumentListLinksNext

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | Link to the next page.  |  [optional]



