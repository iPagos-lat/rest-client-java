
# PayerAuthConfigCardTypesVerifiedByVisa

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**currencies** | [**List&lt;PayerAuthConfigCardTypesVerifiedByVisaCurrencies&gt;**](PayerAuthConfigCardTypesVerifiedByVisaCurrencies.md) |  |  [optional]



