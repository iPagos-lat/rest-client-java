
# Notificationsubscriptionsv1webhooksSecurityPolicyConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oAuthTokenExpiry** | **String** | Token expiration for the oAuth server. |  [optional]
**oAuthURL** | **String** | Client direct endpoint to the oAuth server. |  [optional]
**oAuthTokenType** | **String** | Token type for the oAuth config. |  [optional]



