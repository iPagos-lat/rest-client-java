
# CardProcessingConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**common** | [**CardProcessingConfigCommon**](CardProcessingConfigCommon.md) |  |  [optional]
**features** | [**CardProcessingConfigFeatures**](CardProcessingConfigFeatures.md) |  |  [optional]



