
# InlineResponse4005Fields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **String** | Path of the failed property |  [optional]
**message** | **String** | Error description about validation failed field |  [optional]
**localizationKey** | **String** | Localized Key Name |  [optional]



