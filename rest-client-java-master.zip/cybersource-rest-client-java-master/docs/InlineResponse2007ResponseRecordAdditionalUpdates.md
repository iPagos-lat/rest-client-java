
# InlineResponse2007ResponseRecordAdditionalUpdates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerId** | **String** |  |  [optional]
**paymentInstrumentId** | **String** |  |  [optional]
**creator** | **String** |  |  [optional]
**state** | **String** | Valid Values:   * ACTIVE   * CLOSED  |  [optional]
**message** | **String** |  |  [optional]



