
# InlineResponse200EmbeddedReversalLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**InlineResponse200EmbeddedReversalLinksSelf**](InlineResponse200EmbeddedReversalLinksSelf.md) |  |  [optional]



