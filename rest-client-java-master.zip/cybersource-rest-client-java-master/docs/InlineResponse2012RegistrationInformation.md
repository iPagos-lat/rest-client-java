
# InlineResponse2012RegistrationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**boardingPackageId** | **String** |  |  [optional]
**mode** | [**ModeEnum**](#ModeEnum) | In case mode is not provided the API will use COMPLETE as default Possible Values:   - &#39;COMPLETE&#39;   - &#39;PARTIAL&#39;  |  [optional]
**salesRepId** | **String** |  |  [optional]


<a name="ModeEnum"></a>
## Enum: ModeEnum
Name | Value
---- | -----
COMPLETE | &quot;COMPLETE&quot;
PARTIAL | &quot;PARTIAL&quot;



