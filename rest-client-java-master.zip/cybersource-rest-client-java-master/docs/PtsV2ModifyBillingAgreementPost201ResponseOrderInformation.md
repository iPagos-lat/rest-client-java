
# PtsV2ModifyBillingAgreementPost201ResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billTo** | [**PtsV2ModifyBillingAgreementPost201ResponseOrderInformationBillTo**](PtsV2ModifyBillingAgreementPost201ResponseOrderInformationBillTo.md) |  |  [optional]
**shipTo** | [**PtsV2ModifyBillingAgreementPost201ResponseOrderInformationShipTo**](PtsV2ModifyBillingAgreementPost201ResponseOrderInformationShipTo.md) |  |  [optional]



