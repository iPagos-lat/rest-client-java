
# CreateBinLookupRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Binv1binlookupClientReferenceInformation**](Binv1binlookupClientReferenceInformation.md) |  |  [optional]
**paymentInformation** | [**Binv1binlookupPaymentInformation**](Binv1binlookupPaymentInformation.md) |  |  [optional]
**tokenInformation** | [**Binv1binlookupTokenInformation**](Binv1binlookupTokenInformation.md) |  |  [optional]
**processingInformation** | [**Binv1binlookupProcessingInformation**](Binv1binlookupProcessingInformation.md) |  |  [optional]



