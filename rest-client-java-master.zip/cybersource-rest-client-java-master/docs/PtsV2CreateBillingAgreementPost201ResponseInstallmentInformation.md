
# PtsV2CreateBillingAgreementPost201ResponseInstallmentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identifier** | **String** | Identifier  |  [optional]



