
# InlineResponseDefault

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseStatus** | [**InlineResponseDefaultResponseStatus**](InlineResponseDefaultResponseStatus.md) |  |  [optional]
**links** | [**InlineResponseDefaultLinks**](InlineResponseDefaultLinks.md) |  |  [optional]



