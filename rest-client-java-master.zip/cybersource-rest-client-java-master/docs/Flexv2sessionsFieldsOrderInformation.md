
# Flexv2sessionsFieldsOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**Flexv2sessionsFieldsOrderInformationAmountDetails**](Flexv2sessionsFieldsOrderInformationAmountDetails.md) |  |  [optional]
**billTo** | [**Flexv2sessionsFieldsOrderInformationBillTo**](Flexv2sessionsFieldsOrderInformationBillTo.md) |  |  [optional]
**shipTo** | [**Flexv2sessionsFieldsOrderInformationShipTo**](Flexv2sessionsFieldsOrderInformationShipTo.md) |  |  [optional]



