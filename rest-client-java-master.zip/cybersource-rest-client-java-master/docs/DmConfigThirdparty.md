
# DmConfigThirdparty

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | [**DmConfigThirdpartyProvider**](DmConfigThirdpartyProvider.md) |  |  [optional]



