
# MitVoidRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Ptsv2paymentsClientReferenceInformation**](Ptsv2paymentsClientReferenceInformation.md) |  |  [optional]
**paymentInformation** | [**Ptsv2paymentsidvoidsPaymentInformation**](Ptsv2paymentsidvoidsPaymentInformation.md) |  |  [optional]
**orderInformation** | [**Ptsv2paymentsidvoidsOrderInformation**](Ptsv2paymentsidvoidsOrderInformation.md) |  |  [optional]
**processingInformation** | [**Ptsv2voidsProcessingInformation**](Ptsv2voidsProcessingInformation.md) |  |  [optional]



