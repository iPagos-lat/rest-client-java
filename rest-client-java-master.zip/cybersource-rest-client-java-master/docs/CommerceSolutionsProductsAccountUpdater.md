
# CommerceSolutionsProductsAccountUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsPayerAuthenticationSubscriptionInformation**](PaymentsProductsPayerAuthenticationSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**CommerceSolutionsProductsAccountUpdaterConfigurationInformation**](CommerceSolutionsProductsAccountUpdaterConfigurationInformation.md) |  |  [optional]



