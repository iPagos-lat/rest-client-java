
# InlineResponse409

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;InlineResponse409Errors&gt;**](InlineResponse409Errors.md) |  |  [optional]



