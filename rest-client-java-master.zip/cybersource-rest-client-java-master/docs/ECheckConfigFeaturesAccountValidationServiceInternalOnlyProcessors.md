
# ECheckConfigFeaturesAccountValidationServiceInternalOnlyProcessors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**avsVersion** | **Object** | *NEW* |  [optional]



