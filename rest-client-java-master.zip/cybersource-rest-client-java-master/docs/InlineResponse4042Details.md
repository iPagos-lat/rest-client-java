
# InlineResponse4042Details

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** |  |  [optional]
**reason** | **String** |  |  [optional]



