
# GetAllSubscriptionsResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**GetAllPlansResponseOrderInformationAmountDetails**](GetAllPlansResponseOrderInformationAmountDetails.md) |  |  [optional]
**billTo** | [**GetAllSubscriptionsResponseOrderInformationBillTo**](GetAllSubscriptionsResponseOrderInformationBillTo.md) |  |  [optional]



