
# Boardingv1registrationsIntegrationInformationOauth2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientId** | **String** |  | 
**state** | **String** |  |  [optional]



