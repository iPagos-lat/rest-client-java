
# PaymentsProductsCybsReadyTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsCardPresentConnectSubscriptionInformation**](PaymentsProductsCardPresentConnectSubscriptionInformation.md) |  |  [optional]



