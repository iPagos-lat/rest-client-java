
# AuthReversalRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Ptsv2paymentsidreversalsClientReferenceInformation**](Ptsv2paymentsidreversalsClientReferenceInformation.md) |  |  [optional]
**reversalInformation** | [**Ptsv2paymentsidreversalsReversalInformation**](Ptsv2paymentsidreversalsReversalInformation.md) |  |  [optional]
**processingInformation** | [**Ptsv2paymentsidreversalsProcessingInformation**](Ptsv2paymentsidreversalsProcessingInformation.md) |  |  [optional]
**orderInformation** | [**Ptsv2paymentsidreversalsOrderInformation**](Ptsv2paymentsidreversalsOrderInformation.md) |  |  [optional]
**pointOfSaleInformation** | [**Ptsv2paymentsidreversalsPointOfSaleInformation**](Ptsv2paymentsidreversalsPointOfSaleInformation.md) |  |  [optional]
**paymentInformation** | [**Ptsv2paymentsidreversalsPaymentInformation**](Ptsv2paymentsidreversalsPaymentInformation.md) |  |  [optional]
**processorInformation** | [**Ptsv2paymentsProcessorInformationReversal**](Ptsv2paymentsProcessorInformationReversal.md) |  |  [optional]



