
# CommerceSolutionsProductsBinLookupConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**configurations** | [**CommerceSolutionsProductsBinLookupConfigurationInformationConfigurations**](CommerceSolutionsProductsBinLookupConfigurationInformationConfigurations.md) |  |  [optional]



