
# InlineResponse2012SetupsPayments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardProcessing** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**cardPresentConnect** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**eCheck** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**payerAuthentication** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**digitalPayments** | [**InlineResponse2012SetupsPaymentsDigitalPayments**](InlineResponse2012SetupsPaymentsDigitalPayments.md) |  |  [optional]
**secureAcceptance** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**virtualTerminal** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**currencyConversion** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**tax** | [**InlineResponse2012SetupsPaymentsDigitalPayments**](InlineResponse2012SetupsPaymentsDigitalPayments.md) |  |  [optional]
**customerInvoicing** | [**InlineResponse2012SetupsPaymentsDigitalPayments**](InlineResponse2012SetupsPaymentsDigitalPayments.md) |  |  [optional]
**recurringBilling** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**cybsReadyTerminal** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**paymentOrchestration** | [**InlineResponse2012SetupsPaymentsDigitalPayments**](InlineResponse2012SetupsPaymentsDigitalPayments.md) |  |  [optional]
**payouts** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**payByLink** | [**InlineResponse2012SetupsPaymentsDigitalPayments**](InlineResponse2012SetupsPaymentsDigitalPayments.md) |  |  [optional]
**unifiedCheckout** | [**InlineResponse2012SetupsPaymentsDigitalPayments**](InlineResponse2012SetupsPaymentsDigitalPayments.md) |  |  [optional]
**receivablesManager** | [**InlineResponse2012SetupsPaymentsDigitalPayments**](InlineResponse2012SetupsPaymentsDigitalPayments.md) |  |  [optional]
**serviceFee** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]



