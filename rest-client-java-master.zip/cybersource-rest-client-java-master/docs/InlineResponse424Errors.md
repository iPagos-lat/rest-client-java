
# InlineResponse424Errors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | The type of error.  Possible Values:   - notFound  |  [optional]
**message** | **String** | The detailed message related to the type. |  [optional]



