
# Invoicingv2invoicesOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**Invoicingv2invoicesOrderInformationAmountDetails**](Invoicingv2invoicesOrderInformationAmountDetails.md) |  |  [optional]
**lineItems** | [**List&lt;Invoicingv2invoicesOrderInformationLineItems&gt;**](Invoicingv2invoicesOrderInformationLineItems.md) |  |  [optional]



