
# PaymentsProductsECheckConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templateId** | [**UUID**](UUID.md) |  |  [optional]
**configurations** | [**ECheckConfig**](ECheckConfig.md) |  |  [optional]



