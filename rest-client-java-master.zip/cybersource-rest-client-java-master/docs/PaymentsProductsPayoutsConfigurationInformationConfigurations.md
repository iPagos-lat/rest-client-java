
# PaymentsProductsPayoutsConfigurationInformationConfigurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pullfunds** | [**Map&lt;String, PaymentsProductsPayoutsConfigurationInformationConfigurationsPullfunds&gt;**](PaymentsProductsPayoutsConfigurationInformationConfigurationsPullfunds.md) |  |  [optional]
**pushfunds** | [**Map&lt;String, PaymentsProductsPayoutsConfigurationInformationConfigurationsPushfunds&gt;**](PaymentsProductsPayoutsConfigurationInformationConfigurationsPushfunds.md) |  |  [optional]



