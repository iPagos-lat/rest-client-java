
# InlineResponse4001Details

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** |  |  [optional]
**message** | **String** |  |  [optional]



