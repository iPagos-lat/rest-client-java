
# PaymentsProductsCardPresentConnectConfigurationInformationConfigurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**partnerSolutionIdentifier** | **String** | Solution identifier used to associate a partner organization with the Merchant that is on-boarded. |  [optional]



