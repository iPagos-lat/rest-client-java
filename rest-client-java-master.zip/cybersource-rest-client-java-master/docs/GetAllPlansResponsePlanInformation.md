
# GetAllPlansResponsePlanInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | Plan code  |  [optional]
**status** | **String** | Plan Status:  - &#x60;DRAFT&#x60;  - &#x60;ACTIVE&#x60;  - &#x60;INACTIVE&#x60;  |  [optional]
**name** | **String** | Plan name  |  [optional]
**description** | **String** | Plan description  |  [optional]
**billingPeriod** | [**GetAllPlansResponsePlanInformationBillingPeriod**](GetAllPlansResponsePlanInformationBillingPeriod.md) |  |  [optional]
**billingCycles** | [**GetAllPlansResponsePlanInformationBillingCycles**](GetAllPlansResponsePlanInformationBillingCycles.md) |  |  [optional]



