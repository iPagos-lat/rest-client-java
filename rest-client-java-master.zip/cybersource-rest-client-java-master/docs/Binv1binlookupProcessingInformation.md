
# Binv1binlookupProcessingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**binSource** | **String** | Bin Source File Identifier.  Possible values: - itmx - rupay  |  [optional]
**payoutOptions** | [**Binv1binlookupProcessingInformationPayoutOptions**](Binv1binlookupProcessingInformationPayoutOptions.md) |  |  [optional]



