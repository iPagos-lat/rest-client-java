
# PtsV1TransactionBatchesGet400ResponseErrorInformationDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** | This is the flattened JSON object field name/path that is either missing or invalid.  |  [optional]
**message** | **String** | The detailed message related to the status and reason listed above.  |  [optional]



