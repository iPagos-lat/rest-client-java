
# InlineResponse2012ProductInformationSetups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**organizationId** | **String** |  |  [optional]
**setups** | [**InlineResponse2012Setups**](InlineResponse2012Setups.md) |  |  [optional]



