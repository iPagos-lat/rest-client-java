
# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;InlineResponse2005Links&gt;**](InlineResponse2005Links.md) |  |  [optional]
**object** | **String** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**limit** | **Integer** |  |  [optional]
**count** | **Integer** |  |  [optional]
**total** | **Integer** |  |  [optional]
**embedded** | [**InlineResponse2005Embedded**](InlineResponse2005Embedded.md) |  |  [optional]



