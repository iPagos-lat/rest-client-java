
# DmConfigOrganization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hierarchyGroup** | **String** | Must be one of the following : NO_GROUP, INCLUDE_IN_PARENTS_GROUP  |  [optional]



