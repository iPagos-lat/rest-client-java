
# PtsV2CreateBillingAgreementPost201ResponseRiskInformationProcessorResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**riskScore** | **String** | Risk score returned by the processor. Possible values of 0-10. A value of 10 indicates a high risk.  |  [optional]



