
# Boardingv1registrationsDocumentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**signedDocuments** | [**List&lt;Boardingv1registrationsDocumentInformationSignedDocuments&gt;**](Boardingv1registrationsDocumentInformationSignedDocuments.md) |  |  [optional]



