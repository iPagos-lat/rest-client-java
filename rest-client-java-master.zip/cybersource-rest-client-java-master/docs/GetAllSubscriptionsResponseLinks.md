
# GetAllSubscriptionsResponseLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**PtsV2PaymentsPost201ResponseLinksSelf**](PtsV2PaymentsPost201ResponseLinksSelf.md) |  |  [optional]
**cancel** | [**PtsV2PaymentsPost201ResponseLinksSelf**](PtsV2PaymentsPost201ResponseLinksSelf.md) |  |  [optional]
**suspend** | [**PtsV2PaymentsPost201ResponseLinksSelf**](PtsV2PaymentsPost201ResponseLinksSelf.md) |  |  [optional]
**activate** | [**PtsV2PaymentsPost201ResponseLinksSelf**](PtsV2PaymentsPost201ResponseLinksSelf.md) |  |  [optional]



