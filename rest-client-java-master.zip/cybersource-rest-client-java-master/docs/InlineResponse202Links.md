
# InlineResponse202Links

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**InlineResponse401LinksSelf**](InlineResponse401LinksSelf.md) |  |  [optional]
**status** | [**List&lt;InlineResponse202LinksStatus&gt;**](InlineResponse202LinksStatus.md) |  |  [optional]



