
# InlineResponse401Links

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**InlineResponse401LinksSelf**](InlineResponse401LinksSelf.md) |  |  [optional]



