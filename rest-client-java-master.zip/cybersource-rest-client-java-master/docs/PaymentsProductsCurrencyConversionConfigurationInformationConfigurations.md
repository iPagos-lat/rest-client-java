
# PaymentsProductsCurrencyConversionConfigurationInformationConfigurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processors** | [**Map&lt;String, PaymentsProductsCurrencyConversionConfigurationInformationConfigurationsProcessors&gt;**](PaymentsProductsCurrencyConversionConfigurationInformationConfigurationsProcessors.md) |  |  [optional]



