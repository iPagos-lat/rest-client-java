
# PaymentsProductsDifferentialFeeSubscriptionInformationFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**surcharge** | [**PaymentsProductsDifferentialFeeSubscriptionInformationFeaturesSurcharge**](PaymentsProductsDifferentialFeeSubscriptionInformationFeaturesSurcharge.md) |  |  [optional]



