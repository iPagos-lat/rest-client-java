
# PaymentsProductsSecureAcceptanceConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templateId** | [**UUID**](UUID.md) |  |  [optional]
**configurations** | [**SAConfig**](SAConfig.md) |  |  [optional]



