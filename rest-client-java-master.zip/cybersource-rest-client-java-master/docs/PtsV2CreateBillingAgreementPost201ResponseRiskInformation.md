
# PtsV2CreateBillingAgreementPost201ResponseRiskInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processorResults** | [**PtsV2CreateBillingAgreementPost201ResponseRiskInformationProcessorResults**](PtsV2CreateBillingAgreementPost201ResponseRiskInformationProcessorResults.md) |  |  [optional]



