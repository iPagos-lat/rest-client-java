
# PayerAuthConfigCardTypesJCBJSecure

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**securePasswordForJCB** | **String** | JSecure currency password for Japan Credit Bureau |  [optional]
**enabled** | **Boolean** |  |  [optional]
**currencies** | [**List&lt;PayerAuthConfigCardTypesVerifiedByVisaCurrencies&gt;**](PayerAuthConfigCardTypesVerifiedByVisaCurrencies.md) |  |  [optional]



