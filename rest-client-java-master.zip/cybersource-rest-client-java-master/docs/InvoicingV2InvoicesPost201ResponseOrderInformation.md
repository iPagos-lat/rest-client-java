
# InvoicingV2InvoicesPost201ResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**InvoicingV2InvoicesPost201ResponseOrderInformationAmountDetails**](InvoicingV2InvoicesPost201ResponseOrderInformationAmountDetails.md) |  |  [optional]
**lineItems** | [**List&lt;Invoicingv2invoicesOrderInformationLineItems&gt;**](Invoicingv2invoicesOrderInformationLineItems.md) |  |  [optional]



