
# DmConfigThirdpartyProviderAccurint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**credentials** | [**DmConfigThirdpartyProviderAccurintCredentials**](DmConfigThirdpartyProviderAccurintCredentials.md) |  |  [optional]



