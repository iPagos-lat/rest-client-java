
# PtsV1TransactionBatchesGet400ResponseErrorInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**details** | [**List&lt;PtsV1TransactionBatchesGet400ResponseErrorInformationDetails&gt;**](PtsV1TransactionBatchesGet400ResponseErrorInformationDetails.md) |  |  [optional]



