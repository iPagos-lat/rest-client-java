
# InlineResponse2005EmbeddedLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reports** | [**List&lt;InlineResponse2005EmbeddedLinksReports&gt;**](InlineResponse2005EmbeddedLinksReports.md) |  |  [optional]



