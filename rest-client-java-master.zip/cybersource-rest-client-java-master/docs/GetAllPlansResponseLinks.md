
# GetAllPlansResponseLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**PtsV2PaymentsPost201ResponseLinksSelf**](PtsV2PaymentsPost201ResponseLinksSelf.md) |  |  [optional]
**next** | [**PtsV2PaymentsPost201ResponseLinksSelf**](PtsV2PaymentsPost201ResponseLinksSelf.md) |  |  [optional]
**previous** | [**PtsV2PaymentsPost201ResponseLinksSelf**](PtsV2PaymentsPost201ResponseLinksSelf.md) |  |  [optional]



