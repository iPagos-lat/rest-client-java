
# PaymentsProductsCurrencyConversionConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templateId** | [**UUID**](UUID.md) |  |  [optional]
**configurations** | [**PaymentsProductsCurrencyConversionConfigurationInformationConfigurations**](PaymentsProductsCurrencyConversionConfigurationInformationConfigurations.md) |  |  [optional]



