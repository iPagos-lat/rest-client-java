
# Boardingv1registrationsOrganizationInformationBusinessInformationBusinessContact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** |  | 
**middleName** | **String** |  |  [optional]
**lastName** | **String** |  | 
**phoneNumber** | **String** |  | 
**email** | **String** |  | 



