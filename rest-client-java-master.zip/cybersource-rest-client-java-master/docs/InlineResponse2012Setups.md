
# InlineResponse2012Setups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payments** | [**InlineResponse2012SetupsPayments**](InlineResponse2012SetupsPayments.md) |  |  [optional]
**risk** | [**InlineResponse2012SetupsRisk**](InlineResponse2012SetupsRisk.md) |  |  [optional]
**commerceSolutions** | [**InlineResponse2012SetupsCommerceSolutions**](InlineResponse2012SetupsCommerceSolutions.md) |  |  [optional]
**valueAddedServices** | [**InlineResponse2012SetupsValueAddedServices**](InlineResponse2012SetupsValueAddedServices.md) |  |  [optional]



