
# InlineResponse2012SetupsPaymentsDigitalPayments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionStatus** | [**InlineResponse2012SetupsPaymentsCardProcessingSubscriptionStatus**](InlineResponse2012SetupsPaymentsCardProcessingSubscriptionStatus.md) |  |  [optional]



