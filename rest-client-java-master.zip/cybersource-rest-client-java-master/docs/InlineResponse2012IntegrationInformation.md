
# InlineResponse2012IntegrationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenantConfigurations** | [**List&lt;InlineResponse2012IntegrationInformationTenantConfigurations&gt;**](InlineResponse2012IntegrationInformationTenantConfigurations.md) | tenantConfigurations is an array of objects that includes the tenant information this merchant is associated with. |  [optional]



