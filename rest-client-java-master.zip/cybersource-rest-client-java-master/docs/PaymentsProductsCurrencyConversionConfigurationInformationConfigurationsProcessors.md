
# PaymentsProductsCurrencyConversionConfigurationInformationConfigurationsProcessors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantId** | **String** | The merchant identifier for the Currency Conversion service. Check with your Currency Conversion Provider for details. |  [optional]
**acquirerId** | **String** |  |  [optional]



