
# InvoicingV2InvoicesAllGet200ResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**InvoicingV2InvoicesAllGet200ResponseOrderInformationAmountDetails**](InvoicingV2InvoicesAllGet200ResponseOrderInformationAmountDetails.md) |  |  [optional]



