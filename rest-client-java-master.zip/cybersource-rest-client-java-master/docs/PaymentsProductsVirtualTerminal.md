
# PaymentsProductsVirtualTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsPayerAuthenticationSubscriptionInformation**](PaymentsProductsPayerAuthenticationSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsVirtualTerminalConfigurationInformation**](PaymentsProductsVirtualTerminalConfigurationInformation.md) |  |  [optional]



