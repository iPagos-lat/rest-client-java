
# ECheckConfigFeaturesAccountValidationServiceInternalOnly

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processors** | [**Map&lt;String, ECheckConfigFeaturesAccountValidationServiceInternalOnlyProcessors&gt;**](ECheckConfigFeaturesAccountValidationServiceInternalOnlyProcessors.md) | *NEW* Payment Processing connection used to support eCheck, aka ACH, payment methods. Example * \&quot;bofaach\&quot; * \&quot;wellsfargoach\&quot;  |  [optional]



