
# PaymentsProductsDifferentialFee

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsDifferentialFeeSubscriptionInformation**](PaymentsProductsDifferentialFeeSubscriptionInformation.md) |  |  [optional]



