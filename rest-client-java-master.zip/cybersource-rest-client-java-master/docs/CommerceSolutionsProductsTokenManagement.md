
# CommerceSolutionsProductsTokenManagement

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsPayerAuthenticationSubscriptionInformation**](PaymentsProductsPayerAuthenticationSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**CommerceSolutionsProductsTokenManagementConfigurationInformation**](CommerceSolutionsProductsTokenManagementConfigurationInformation.md) |  |  [optional]



