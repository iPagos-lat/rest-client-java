
# PaymentsProductsPayoutsConfigurationInformationConfigurationsProcessorAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**originatorMerchantId** | **String** | TBD | 
**originatorTerminalId** | **List&lt;String&gt;** | TBD | 
**supportedCurrencies** | **List&lt;String&gt;** | Three-character [ISO Standard Currency Codes.](http://apps.cybersource.com/library/documentation/sbc/quickref/currencies.pdf) |  [optional]



