
# PaymentsProductsCardPresentConnect

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsCardPresentConnectSubscriptionInformation**](PaymentsProductsCardPresentConnectSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsCardPresentConnectConfigurationInformation**](PaymentsProductsCardPresentConnectConfigurationInformation.md) |  |  [optional]



