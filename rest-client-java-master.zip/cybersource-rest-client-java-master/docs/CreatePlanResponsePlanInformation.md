
# CreatePlanResponsePlanInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | Plan code  |  [optional]
**status** | **String** | Plan Status:  - &#x60;DRAFT&#x60;  - &#x60;ACTIVE&#x60;  |  [optional]



