
# InlineResponse2006Links

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**InlineResponse202LinksStatus**](InlineResponse202LinksStatus.md) |  |  [optional]
**report** | [**List&lt;InlineResponse2006LinksReport&gt;**](InlineResponse2006LinksReport.md) |  |  [optional]



