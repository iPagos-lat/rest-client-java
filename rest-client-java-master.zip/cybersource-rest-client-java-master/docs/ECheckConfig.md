
# ECheckConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**common** | [**ECheckConfigCommon**](ECheckConfigCommon.md) |  |  [optional]
**underwriting** | [**ECheckConfigUnderwriting**](ECheckConfigUnderwriting.md) |  |  [optional]
**features** | [**ECheckConfigFeatures**](ECheckConfigFeatures.md) |  |  [optional]



