
# PtsV2PaymentsOrderPost201ResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billTo** | [**PtsV2PaymentsOrderPost201ResponseOrderInformationBillTo**](PtsV2PaymentsOrderPost201ResponseOrderInformationBillTo.md) |  |  [optional]
**shipTo** | [**PtsV2PaymentsOrderPost201ResponseOrderInformationShipTo**](PtsV2PaymentsOrderPost201ResponseOrderInformationShipTo.md) |  |  [optional]
**amountDetails** | [**PtsV2PaymentsOrderPost201ResponseOrderInformationAmountDetails**](PtsV2PaymentsOrderPost201ResponseOrderInformationAmountDetails.md) |  |  [optional]
**shippingDetails** | [**PtsV2PaymentsOrderPost201ResponseOrderInformationShippingDetails**](PtsV2PaymentsOrderPost201ResponseOrderInformationShippingDetails.md) |  |  [optional]



