
# PtsV2PaymentsOrderPost201ResponseProcessingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**intentsId** | **String** | Set to the value of the requestID field returned in the order service response. |  [optional]



