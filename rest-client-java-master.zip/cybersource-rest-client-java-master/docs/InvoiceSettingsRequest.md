
# InvoiceSettingsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**invoiceSettingsInformation** | [**Invoicingv2invoiceSettingsInvoiceSettingsInformation**](Invoicingv2invoiceSettingsInvoiceSettingsInformation.md) |  |  [optional]



