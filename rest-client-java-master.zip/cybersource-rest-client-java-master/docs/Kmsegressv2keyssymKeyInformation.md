
# Kmsegressv2keyssymKeyInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | **String** | Provider name  |  [optional]
**tenant** | **String** | Tenant name  |  [optional]
**keyType** | **String** | Type of the key  |  [optional]
**organizationId** | **String** | Organization Id  |  [optional]
**clientKeyId** | **String** | Client key Id  |  [optional]
**keyId** | **String** | Key Serial Number  |  [optional]
**key** | **String** | Value of the key  |  [optional]
**status** | **String** | The status of the key  |  [optional]
**expiryDuration** | **String** | Key expiry duration in days  |  [optional]



