
# InlineResponse2006Billing

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nan** | **Integer** |  |  [optional]
**ned** | **Integer** |  |  [optional]
**acl** | **Integer** |  |  [optional]
**cch** | **Integer** |  |  [optional]



