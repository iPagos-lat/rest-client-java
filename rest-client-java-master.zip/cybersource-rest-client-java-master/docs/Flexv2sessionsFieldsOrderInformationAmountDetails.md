
# Flexv2sessionsFieldsOrderInformationAmountDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalAmount** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**currency** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]



