
# InlineResponse410Errors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | The type of error.  Possible Values:   - notAvailable  |  [optional]
**message** | **String** | The detailed message related to the type. |  [optional]



