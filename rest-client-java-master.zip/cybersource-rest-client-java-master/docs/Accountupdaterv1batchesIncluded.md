
# Accountupdaterv1batchesIncluded

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tokens** | [**List&lt;Accountupdaterv1batchesIncludedTokens&gt;**](Accountupdaterv1batchesIncludedTokens.md) |  |  [optional]



