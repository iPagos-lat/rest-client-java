
# PaymentsProductsCardPresentConnectSubscriptionInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**selfServiceability** | [**SelfServiceabilityEnum**](#SelfServiceabilityEnum) | Indicates if the organization can enable this product using self service. |  [optional]


<a name="SelfServiceabilityEnum"></a>
## Enum: SelfServiceabilityEnum
Name | Value
---- | -----
NOT_SELF_SERVICEABLE | &quot;NOT_SELF_SERVICEABLE&quot;



