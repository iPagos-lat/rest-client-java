
# Flexv2sessionsFieldsPaymentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**card** | [**Flexv2sessionsFieldsPaymentInformationCard**](Flexv2sessionsFieldsPaymentInformationCard.md) |  |  [optional]



