
# InlineResponse2007SourceRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  |  [optional]
**customerId** | **String** |  |  [optional]
**paymentInstrumentId** | **String** |  |  [optional]
**instrumentIdentifierId** | **String** |  |  [optional]
**cardNumber** | **String** |  |  [optional]
**cardExpiryMonth** | **String** |  |  [optional]
**cardExpiryYear** | **String** |  |  [optional]
**cardType** | **String** |  |  [optional]



