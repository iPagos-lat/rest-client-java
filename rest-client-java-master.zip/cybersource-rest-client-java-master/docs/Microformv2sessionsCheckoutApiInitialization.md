
# Microformv2sessionsCheckoutApiInitialization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**profileId** | **String** |  |  [optional]
**accessKey** | **String** |  |  [optional]
**referenceNumber** | **String** |  |  [optional]
**transactionUuid** | **String** |  |  [optional]
**transactionType** | **String** |  |  [optional]
**currency** | **String** |  |  [optional]
**amount** | **String** |  |  [optional]
**locale** | **String** |  |  [optional]
**overrideCustomReceiptPage** | **String** |  |  [optional]
**unsignedFieldNames** | **String** |  |  [optional]



