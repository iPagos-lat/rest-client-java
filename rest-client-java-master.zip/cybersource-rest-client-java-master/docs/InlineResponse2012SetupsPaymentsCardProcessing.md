
# InlineResponse2012SetupsPaymentsCardProcessing

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionStatus** | [**InlineResponse2012SetupsPaymentsCardProcessingSubscriptionStatus**](InlineResponse2012SetupsPaymentsCardProcessingSubscriptionStatus.md) |  |  [optional]
**configurationStatus** | [**InlineResponse2012SetupsPaymentsCardProcessingConfigurationStatus**](InlineResponse2012SetupsPaymentsCardProcessingConfigurationStatus.md) |  |  [optional]



