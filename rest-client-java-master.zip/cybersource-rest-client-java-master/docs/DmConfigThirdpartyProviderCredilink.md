
# DmConfigThirdpartyProviderCredilink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**enableRealTime** | **Boolean** |  |  [optional]
**useCybsCredentials** | **Boolean** |  |  [optional]
**credentials** | [**DmConfigThirdpartyProviderCredilinkCredentials**](DmConfigThirdpartyProviderCredilinkCredentials.md) |  |  [optional]



