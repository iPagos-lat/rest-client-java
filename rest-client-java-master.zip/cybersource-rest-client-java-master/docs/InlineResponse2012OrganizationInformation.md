
# InlineResponse2012OrganizationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**organizationId** | **String** |  |  [optional]
**parentOrganizationId** | **String** |  |  [optional]
**childOrganizations** | **List&lt;String&gt;** |  |  [optional]



