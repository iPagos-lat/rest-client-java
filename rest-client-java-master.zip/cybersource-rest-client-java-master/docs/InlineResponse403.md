
# InlineResponse403

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;InlineResponse403Errors&gt;**](InlineResponse403Errors.md) |  |  [optional]



