
# PaymentsProductsServiceFeeConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**configurations** | [**PaymentsProductsServiceFeeConfigurationInformationConfigurations**](PaymentsProductsServiceFeeConfigurationInformationConfigurations.md) |  |  [optional]



