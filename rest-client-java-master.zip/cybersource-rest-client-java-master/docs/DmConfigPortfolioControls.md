
# DmConfigPortfolioControls

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hideRiskMenus** | **Boolean** |  |  [optional]
**hideRiskTransactionData** | **Boolean** |  |  [optional]



