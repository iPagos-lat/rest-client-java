
# Notificationsubscriptionsv1webhooksSecurityPolicy1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**securityType** | **String** | Security Policy of the client server. |  [optional]
**proxyType** | **String** | Internal client proxy type to be used by security policy. |  [optional]
**config** | [**Notificationsubscriptionsv1webhooksSecurityPolicy1Config**](Notificationsubscriptionsv1webhooksSecurityPolicy1Config.md) |  |  [optional]



