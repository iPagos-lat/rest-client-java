
# InlineResponse2013KeyInformationErrorInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** | The reason of the status. Possible values:  - MISSING_FIELD  - INVALID_DATA  |  [optional]
**details** | [**List&lt;InlineResponse2013KeyInformationErrorInformationDetails&gt;**](InlineResponse2013KeyInformationErrorInformationDetails.md) |  |  [optional]



