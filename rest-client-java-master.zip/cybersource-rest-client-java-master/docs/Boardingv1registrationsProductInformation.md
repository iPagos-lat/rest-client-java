
# Boardingv1registrationsProductInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**selectedProducts** | [**Boardingv1registrationsProductInformationSelectedProducts**](Boardingv1registrationsProductInformationSelectedProducts.md) |  |  [optional]



