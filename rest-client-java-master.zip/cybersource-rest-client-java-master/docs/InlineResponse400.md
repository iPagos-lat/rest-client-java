
# InlineResponse400

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;InlineResponse400Errors&gt;**](InlineResponse400Errors.md) |  |  [optional]



