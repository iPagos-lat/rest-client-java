
# PtsV1TransactionBatchesGet200ResponseLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**PtsV1TransactionBatchesGet200ResponseLinksSelf**](PtsV1TransactionBatchesGet200ResponseLinksSelf.md) |  |  [optional]



