
# PtsV2ModifyBillingAgreementPost201ResponsePaymentInformationBank

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iban** | **String** | International Bank Account Number (IBAN).  |  [optional]



