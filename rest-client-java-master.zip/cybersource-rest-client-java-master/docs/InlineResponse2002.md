
# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productId** | **String** | Product ID. |  [optional]
**productName** | **String** | Product Name. |  [optional]
**eventTypes** | [**List&lt;Notificationsubscriptionsv1productsorganizationIdEventTypes&gt;**](Notificationsubscriptionsv1productsorganizationIdEventTypes.md) |  |  [optional]



