
# PaymentsProductsPayoutsConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**configurations** | [**PaymentsProductsPayoutsConfigurationInformationConfigurations**](PaymentsProductsPayoutsConfigurationInformationConfigurations.md) |  |  [optional]



