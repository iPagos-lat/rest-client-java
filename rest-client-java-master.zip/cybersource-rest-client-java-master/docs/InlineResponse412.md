
# InlineResponse412

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;InlineResponse412Errors&gt;**](InlineResponse412Errors.md) |  |  [optional]



