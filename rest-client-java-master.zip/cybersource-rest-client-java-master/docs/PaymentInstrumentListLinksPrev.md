
# PaymentInstrumentListLinksPrev

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | Link to the previous page.  |  [optional]



