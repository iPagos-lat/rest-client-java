
# InlineResponse200EmbeddedReversal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | The status of the reversal if the auth reversal is called.  |  [optional]
**links** | [**InlineResponse200EmbeddedReversalLinks**](InlineResponse200EmbeddedReversalLinks.md) |  |  [optional]



