
# PtsV2PaymentsCapturesPost201ResponseOrderInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountDetails** | [**PtsV2PaymentsCapturesPost201ResponseOrderInformationAmountDetails**](PtsV2PaymentsCapturesPost201ResponseOrderInformationAmountDetails.md) |  |  [optional]
**invoiceDetails** | [**PtsV2PaymentsCapturesPost201ResponseOrderInformationInvoiceDetails**](PtsV2PaymentsCapturesPost201ResponseOrderInformationInvoiceDetails.md) |  |  [optional]



