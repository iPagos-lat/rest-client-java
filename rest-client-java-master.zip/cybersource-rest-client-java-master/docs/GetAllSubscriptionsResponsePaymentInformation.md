
# GetAllSubscriptionsResponsePaymentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customer** | [**GetAllSubscriptionsResponsePaymentInformationCustomer**](GetAllSubscriptionsResponsePaymentInformationCustomer.md) |  |  [optional]



