
# CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**masterCard** | [**CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsMasterCard**](CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsMasterCard.md) |  |  [optional]
**visa** | [**CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsVisa**](CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsVisa.md) |  |  [optional]
**amex** | [**CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsAmex**](CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsAmex.md) |  |  [optional]
**preferredDay** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**daysWindow** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



