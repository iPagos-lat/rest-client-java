
# PtsV1TransactionBatchesIdGet200ResponseLinksTransactions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | Self link for this request |  [optional]
**method** | **String** |  |  [optional]



