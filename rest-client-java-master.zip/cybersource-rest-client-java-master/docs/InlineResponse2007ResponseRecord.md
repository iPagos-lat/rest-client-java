
# InlineResponse2007ResponseRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | **String** | Valid Values:   * NAN   * NED   * ACL   * CCH   * CUR   * NUP   * UNA   * ERR   * DEC  |  [optional]
**reason** | **String** |  |  [optional]
**token** | **String** |  |  [optional]
**instrumentIdentifierId** | **String** |  |  [optional]
**instrumentIdentifierCreated** | **String** | Valid Values:   * true   * false  |  [optional]
**cardNumber** | **String** |  |  [optional]
**cardExpiryMonth** | **String** |  |  [optional]
**cardExpiryYear** | **String** |  |  [optional]
**cardType** | **String** |  |  [optional]
**additionalUpdates** | [**List&lt;InlineResponse2007ResponseRecordAdditionalUpdates&gt;**](InlineResponse2007ResponseRecordAdditionalUpdates.md) |  |  [optional]



