
# DmConfigThirdpartyProviderEkata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**enableRealTime** | **Boolean** |  |  [optional]
**useCybsCredentials** | **Boolean** |  |  [optional]
**credentials** | [**DmConfigThirdpartyProviderEkataCredentials**](DmConfigThirdpartyProviderEkataCredentials.md) |  |  [optional]



