
# PtsV1TransactionBatchesGet200ResponseLinksSelf

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** |  |  [optional]
**method** | **String** |  |  [optional]



