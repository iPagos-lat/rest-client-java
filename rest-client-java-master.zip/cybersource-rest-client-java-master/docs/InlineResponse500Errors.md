
# InlineResponse500Errors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | The type of error.  Possible Values:   - internalError  |  [optional]
**message** | **String** | The detailed message related to the type. |  [optional]



