
# PaymentInstrumentList1Embedded

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paymentInstruments** | [**List&lt;PaymentInstrumentList1EmbeddedPaymentInstruments&gt;**](PaymentInstrumentList1EmbeddedPaymentInstruments.md) |  |  [optional]



