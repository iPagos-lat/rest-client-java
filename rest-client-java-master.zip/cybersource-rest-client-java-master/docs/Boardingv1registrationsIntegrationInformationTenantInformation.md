
# Boardingv1registrationsIntegrationInformationTenantInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenantId** | **String** | The TenantId is an external Solution Identifier given by Tech Partners like SAP. |  [optional]



