
# FraudMarkingActionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**riskInformation** | [**Riskv1decisionsidmarkingRiskInformation**](Riskv1decisionsidmarkingRiskInformation.md) |  | 
**clientReferenceInformation** | [**Riskv1liststypeentriesClientReferenceInformation**](Riskv1liststypeentriesClientReferenceInformation.md) |  |  [optional]



