
# DmConfigThirdpartyProviderPerseuss

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**enableRealTime** | **Boolean** |  |  [optional]
**credentials** | [**DmConfigThirdpartyProviderAccurintCredentials**](DmConfigThirdpartyProviderAccurintCredentials.md) |  |  [optional]



