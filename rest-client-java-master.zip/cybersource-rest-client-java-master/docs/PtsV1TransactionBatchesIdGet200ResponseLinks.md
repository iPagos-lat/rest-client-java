
# PtsV1TransactionBatchesIdGet200ResponseLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactions** | [**List&lt;PtsV1TransactionBatchesIdGet200ResponseLinksTransactions&gt;**](PtsV1TransactionBatchesIdGet200ResponseLinksTransactions.md) |  |  [optional]



