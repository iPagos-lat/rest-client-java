
# Body

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Valid Values:   * oneOff   * amexRegistration  |  [optional]
**included** | [**Accountupdaterv1batchesIncluded**](Accountupdaterv1batchesIncluded.md) |  | 
**merchantReference** | **String** | Reference used by merchant to identify batch. |  [optional]
**notificationEmail** | **String** | Email used to notify the batch status. | 



