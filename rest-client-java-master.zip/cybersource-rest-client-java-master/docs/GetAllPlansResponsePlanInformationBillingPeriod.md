
# GetAllPlansResponsePlanInformationBillingPeriod

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | **String** | Example: - If length&#x3D;1 &amp; unit&#x3D;month then charge every month - If length&#x3D;7 &amp; unit&#x3D;day then charge every 7th day  |  [optional]
**unit** | **String** | Calendar unit values.   possible values:   - &#x60;D&#x60; - day   - &#x60;M&#x60; - month   - &#x60;W&#x60; - week   - &#x60;Y&#x60; - year  |  [optional]



