
# PtsV2ModifyBillingAgreementPost201ResponsePaymentInformationEWallet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **String** | The ID of the customer, passed in the return_url field by PayPal after customer approval.  |  [optional]



