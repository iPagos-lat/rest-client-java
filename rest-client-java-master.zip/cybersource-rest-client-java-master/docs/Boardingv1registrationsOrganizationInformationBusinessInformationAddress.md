
# Boardingv1registrationsOrganizationInformationBusinessInformationAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country** | **String** |  | 
**address1** | **String** |  | 
**address2** | **String** |  |  [optional]
**locality** | **String** | City of the billing address. | 
**administrativeArea** | **String** | State or province of the billing address. Required for United States and Canada. |  [optional]
**postalCode** | **String** | Postal code for the billing address. The postal code must consist of 5 to 9 digits. Required for United States and Canada. |  [optional]



