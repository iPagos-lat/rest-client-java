
# Notificationsubscriptionsv1webhooksProducts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productId** | **String** | Product ID. |  [optional]
**eventTypes** | **List&lt;String&gt;** |  |  [optional]



