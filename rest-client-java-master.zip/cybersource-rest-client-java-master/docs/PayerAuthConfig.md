
# PayerAuthConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardTypes** | [**PayerAuthConfigCardTypes**](PayerAuthConfigCardTypes.md) |  |  [optional]



