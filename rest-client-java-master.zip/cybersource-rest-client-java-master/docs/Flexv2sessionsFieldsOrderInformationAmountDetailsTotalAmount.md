
# Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**required** | **Boolean** |  |  [optional]



