
# Binv1binlookupPaymentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**card** | [**Binv1binlookupPaymentInformationCard**](Binv1binlookupPaymentInformationCard.md) |  |  [optional]
**customer** | [**GetAllSubscriptionsResponsePaymentInformationCustomer**](GetAllSubscriptionsResponsePaymentInformationCustomer.md) |  |  [optional]
**paymentInstrument** | [**Ptsv2paymentsPaymentInformationPaymentInstrument**](Ptsv2paymentsPaymentInformationPaymentInstrument.md) |  |  [optional]
**instrumentIdentifier** | [**Ptsv2paymentsPaymentInformationInstrumentIdentifier**](Ptsv2paymentsPaymentInformationInstrumentIdentifier.md) |  |  [optional]



