
# Flexv2sessionsFieldsPaymentInformationCard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**type** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**securityCode** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**expirationMonth** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**expirationYear** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]



