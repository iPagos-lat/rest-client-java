
# CaseManagementActionsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**decisionInformation** | [**Riskv1decisionsidactionsDecisionInformation**](Riskv1decisionsidactionsDecisionInformation.md) |  | 
**processingInformation** | [**Riskv1decisionsidactionsProcessingInformation**](Riskv1decisionsidactionsProcessingInformation.md) |  |  [optional]



