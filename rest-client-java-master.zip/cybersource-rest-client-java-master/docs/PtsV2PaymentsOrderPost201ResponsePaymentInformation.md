
# PtsV2PaymentsOrderPost201ResponsePaymentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eWallet** | [**PtsV2PaymentsOrderPost201ResponsePaymentInformationEWallet**](PtsV2PaymentsOrderPost201ResponsePaymentInformationEWallet.md) |  |  [optional]



