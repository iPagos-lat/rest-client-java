
# Boardingv1registrationsIntegrationInformationTenantConfigurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**solutionId** | **String** | The solutionId is the unique identifier for this system resource. Partner can use it to reference the specific solution through out the system.  | 
**tenantInformation** | [**Boardingv1registrationsIntegrationInformationTenantInformation**](Boardingv1registrationsIntegrationInformationTenantInformation.md) |  |  [optional]



