
# PayerAuthConfigCardTypes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**verifiedByVisa** | [**PayerAuthConfigCardTypesVerifiedByVisa**](PayerAuthConfigCardTypesVerifiedByVisa.md) |  |  [optional]
**masterCardSecureCode** | [**PayerAuthConfigCardTypesVerifiedByVisa**](PayerAuthConfigCardTypesVerifiedByVisa.md) |  |  [optional]
**amexSafeKey** | [**PayerAuthConfigCardTypesVerifiedByVisa**](PayerAuthConfigCardTypesVerifiedByVisa.md) |  |  [optional]
**jCBJSecure** | [**PayerAuthConfigCardTypesJCBJSecure**](PayerAuthConfigCardTypesJCBJSecure.md) |  |  [optional]
**dinersClubInternationalProtectBuy** | [**PayerAuthConfigCardTypesVerifiedByVisa**](PayerAuthConfigCardTypesVerifiedByVisa.md) |  |  [optional]
**ELO** | [**PayerAuthConfigCardTypesVerifiedByVisa**](PayerAuthConfigCardTypesVerifiedByVisa.md) |  |  [optional]
**UPI** | [**PayerAuthConfigCardTypesVerifiedByVisa**](PayerAuthConfigCardTypesVerifiedByVisa.md) |  |  [optional]
**CB** | [**PayerAuthConfigCardTypesCB**](PayerAuthConfigCardTypesCB.md) |  |  [optional]



