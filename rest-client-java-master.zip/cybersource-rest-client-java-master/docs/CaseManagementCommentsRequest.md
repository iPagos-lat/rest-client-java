
# CaseManagementCommentsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comments** | **String** | Comments to be added to case. | 



