
# Boardingv1registrationsProductInformationSelectedProducts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payments** | [**PaymentsProducts**](PaymentsProducts.md) |  |  [optional]
**risk** | [**RiskProducts**](RiskProducts.md) |  |  [optional]
**commerceSolutions** | [**CommerceSolutionsProducts**](CommerceSolutionsProducts.md) |  |  [optional]
**valueAddedServices** | [**ValueAddedServicesProducts**](ValueAddedServicesProducts.md) |  |  [optional]



