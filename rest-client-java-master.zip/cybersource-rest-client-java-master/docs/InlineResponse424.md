
# InlineResponse424

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;InlineResponse424Errors&gt;**](InlineResponse424Errors.md) |  |  [optional]



