
# DmConfigProcessingOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stepUpAuthEnabled** | **Boolean** |  |  [optional]



