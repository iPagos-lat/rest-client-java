
# InlineResponse2011PayoutInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pushFunds** | [**InlineResponse2011PayoutInformationPushFunds**](InlineResponse2011PayoutInformationPushFunds.md) |  |  [optional]
**pullFunds** | [**InlineResponse2011PayoutInformationPullFunds**](InlineResponse2011PayoutInformationPullFunds.md) |  |  [optional]
**geoRestrictionIndicator** | **String** | This field indicates if the recipient issuer can accept transactions from the originator country. Possible values:   - &#x60;Y&#x60;   - &#x60;N&#x60;  |  [optional]



