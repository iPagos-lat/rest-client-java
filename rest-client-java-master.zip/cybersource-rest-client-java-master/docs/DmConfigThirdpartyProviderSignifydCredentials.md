
# DmConfigThirdpartyProviderSignifydCredentials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**teamId** | **String** |  |  [optional]
**apiKey** | **String** |  |  [optional]
**secretKeyid** | **String** |  |  [optional]
**secretKey** | **String** |  |  [optional]



