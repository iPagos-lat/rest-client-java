
# GetAllPlansResponsePlanInformationBillingCycles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **String** | Describe total number of billing cycles  |  [optional]



