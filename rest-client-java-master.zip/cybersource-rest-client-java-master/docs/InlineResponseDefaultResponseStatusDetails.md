
# InlineResponseDefaultResponseStatusDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Field name referred to for validation issues. |  [optional]
**message** | **String** | Description or code of any error response. |  [optional]



