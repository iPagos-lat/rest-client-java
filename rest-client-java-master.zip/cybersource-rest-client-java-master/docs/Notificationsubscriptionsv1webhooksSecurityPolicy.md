
# Notificationsubscriptionsv1webhooksSecurityPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**securityType** | **String** | Security Policy of the client server. |  [optional]
**config** | [**Notificationsubscriptionsv1webhooksSecurityPolicyConfig**](Notificationsubscriptionsv1webhooksSecurityPolicyConfig.md) |  |  [optional]



