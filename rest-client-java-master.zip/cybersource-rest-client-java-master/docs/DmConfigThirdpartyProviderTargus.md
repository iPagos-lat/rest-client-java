
# DmConfigThirdpartyProviderTargus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**useCybsCredentials** | **Boolean** |  |  [optional]
**credentials** | [**DmConfigThirdpartyProviderTargusCredentials**](DmConfigThirdpartyProviderTargusCredentials.md) |  |  [optional]



