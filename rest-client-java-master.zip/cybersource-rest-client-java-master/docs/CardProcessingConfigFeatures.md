
# CardProcessingConfigFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardNotPresent** | [**CardProcessingConfigFeaturesCardNotPresent**](CardProcessingConfigFeaturesCardNotPresent.md) |  |  [optional]
**cardPresent** | [**CardProcessingConfigFeaturesCardPresent**](CardProcessingConfigFeaturesCardPresent.md) |  |  [optional]



