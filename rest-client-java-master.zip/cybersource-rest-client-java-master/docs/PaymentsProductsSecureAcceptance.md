
# PaymentsProductsSecureAcceptance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsPayerAuthenticationSubscriptionInformation**](PaymentsProductsPayerAuthenticationSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsSecureAcceptanceConfigurationInformation**](PaymentsProductsSecureAcceptanceConfigurationInformation.md) |  |  [optional]



