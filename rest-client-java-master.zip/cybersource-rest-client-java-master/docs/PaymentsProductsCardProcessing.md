
# PaymentsProductsCardProcessing

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsCardProcessingSubscriptionInformation**](PaymentsProductsCardProcessingSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsCardProcessingConfigurationInformation**](PaymentsProductsCardProcessingConfigurationInformation.md) |  |  [optional]



