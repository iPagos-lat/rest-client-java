
# IncrementAuthRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Ptsv2paymentsidClientReferenceInformation**](Ptsv2paymentsidClientReferenceInformation.md) |  |  [optional]
**processingInformation** | [**Ptsv2paymentsidProcessingInformation**](Ptsv2paymentsidProcessingInformation.md) |  |  [optional]
**orderInformation** | [**Ptsv2paymentsidOrderInformation**](Ptsv2paymentsidOrderInformation.md) |  |  [optional]
**merchantInformation** | [**Ptsv2paymentsidMerchantInformation**](Ptsv2paymentsidMerchantInformation.md) |  |  [optional]
**travelInformation** | [**Ptsv2paymentsidTravelInformation**](Ptsv2paymentsidTravelInformation.md) |  |  [optional]



