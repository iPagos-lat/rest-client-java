
# CommerceSolutionsProductsBinLookupConfigurationInformationConfigurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isPayoutOptionsEnabled** | **Boolean** | This flag indicates if the merchant is configured to make payout calls |  [optional]
**isAccountPrefixEnabled** | **Boolean** | This flag indicates if the merchant is configured to receive account prefix |  [optional]



