
# ECheckConfigFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountValidationService** | [**ECheckConfigFeaturesAccountValidationService**](ECheckConfigFeaturesAccountValidationService.md) |  |  [optional]



