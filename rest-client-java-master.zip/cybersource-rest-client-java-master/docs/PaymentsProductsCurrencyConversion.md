
# PaymentsProductsCurrencyConversion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsPayerAuthenticationSubscriptionInformation**](PaymentsProductsPayerAuthenticationSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsCurrencyConversionConfigurationInformation**](PaymentsProductsCurrencyConversionConfigurationInformation.md) |  |  [optional]



