
# Flexv2sessionsFieldsOrderInformationBillTo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address1** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**address2** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**administrativeArea** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**buildingNumber** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**country** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**district** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**locality** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**postalCode** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**email** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**firstName** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**lastName** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**phoneNumber** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]
**company** | [**Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount**](Flexv2sessionsFieldsOrderInformationAmountDetailsTotalAmount.md) |  |  [optional]



