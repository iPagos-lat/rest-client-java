
# CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsVisa

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantId** | **String** | Visa merchant identified number | 
**segmentId** | **String** | Visa assigned segment ID for each group of merchants participating in VAU. | 
**active** | **Boolean** |  |  [optional]



