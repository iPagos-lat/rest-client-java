
# PtsV1TransactionBatchesGet500ResponseErrorInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** | The reason of status |  [optional]
**message** | **String** | The detailed message related to the status and reason listed above. |  [optional]



