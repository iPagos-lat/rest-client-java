
# CreateSubscriptionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Rbsv1subscriptionsClientReferenceInformation**](Rbsv1subscriptionsClientReferenceInformation.md) |  |  [optional]
**processingInformation** | [**Rbsv1subscriptionsProcessingInformation**](Rbsv1subscriptionsProcessingInformation.md) |  |  [optional]
**planInformation** | [**Rbsv1subscriptionsPlanInformation**](Rbsv1subscriptionsPlanInformation.md) |  |  [optional]
**subscriptionInformation** | [**Rbsv1subscriptionsSubscriptionInformation**](Rbsv1subscriptionsSubscriptionInformation.md) |  |  [optional]
**paymentInformation** | [**Rbsv1subscriptionsPaymentInformation**](Rbsv1subscriptionsPaymentInformation.md) |  |  [optional]
**orderInformation** | [**GetAllPlansResponseOrderInformation**](GetAllPlansResponseOrderInformation.md) |  |  [optional]



