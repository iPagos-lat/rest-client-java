
# Boardingv1registrationsOrganizationInformationKYCDepositBankAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountHolderName** | **String** |  | 
**accountType** | [**AccountTypeEnum**](#AccountTypeEnum) |  | 
**accountRoutingNumber** | **String** |  | 
**accountNumber** | **String** |  | 


<a name="AccountTypeEnum"></a>
## Enum: AccountTypeEnum
Name | Value
---- | -----
CHECKING | &quot;checking&quot;
SAVINGS | &quot;savings&quot;
CORPORATECHECKING | &quot;corporatechecking&quot;
CORPORATESAVINGS | &quot;corporatesavings&quot;



