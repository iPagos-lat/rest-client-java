
# PaymentsProductsServiceFeeConfigurationInformationConfigurationsProducts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceFeeEnabled** | **Boolean** | Boolean flag to determine if service fee will be applied to the Product. |  [optional]



