
# PaymentsProductsPayerAuthenticationConfigurationInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templateId** | [**UUID**](UUID.md) |  |  [optional]
**configurations** | [**PayerAuthConfig**](PayerAuthConfig.md) |  |  [optional]



