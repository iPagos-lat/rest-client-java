
# CreateInvoiceRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerInformation** | [**Invoicingv2invoicesCustomerInformation**](Invoicingv2invoicesCustomerInformation.md) |  |  [optional]
**invoiceInformation** | [**Invoicingv2invoicesInvoiceInformation**](Invoicingv2invoicesInvoiceInformation.md) |  |  [optional]
**orderInformation** | [**Invoicingv2invoicesOrderInformation**](Invoicingv2invoicesOrderInformation.md) |  |  [optional]



