
# InlineResponse2012SetupsRisk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fraudManagementEssentials** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]
**decisionManager** | [**InlineResponse2012SetupsPaymentsCardProcessing**](InlineResponse2012SetupsPaymentsCardProcessing.md) |  |  [optional]



