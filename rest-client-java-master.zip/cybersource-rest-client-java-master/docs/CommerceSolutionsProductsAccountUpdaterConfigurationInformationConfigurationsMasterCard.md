
# CommerceSolutionsProductsAccountUpdaterConfigurationInformationConfigurationsMasterCard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantId** | **String** | MasterCard merchant identified number | 
**interbankCardAssociationNumber** | **String** | Number assigned by MasterCard to a financial institution, third-party processor or other member to identify the member in transaction. | 
**active** | **Boolean** |  |  [optional]



