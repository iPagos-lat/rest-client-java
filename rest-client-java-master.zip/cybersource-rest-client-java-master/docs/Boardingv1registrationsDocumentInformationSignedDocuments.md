
# Boardingv1registrationsDocumentInformationSignedDocuments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**documentId** | **String** |  |  [optional]



