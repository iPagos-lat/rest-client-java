
# Notificationsubscriptionsv1productsorganizationIdEventTypes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eventName** | **String** |  |  [optional]
**displayName** | **String** |  |  [optional]
**frequency** | **Integer** |  |  [optional]
**timeSensitivity** | **Boolean** |  |  [optional]
**payloadEncryption** | **Boolean** |  |  [optional]



