
# PaymentInstrumentListLinksFirst

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** | Link to the first page.  |  [optional]



