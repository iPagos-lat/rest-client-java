
# DmConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processingOptions** | [**DmConfigProcessingOptions**](DmConfigProcessingOptions.md) |  |  [optional]
**organization** | [**DmConfigOrganization**](DmConfigOrganization.md) |  |  [optional]
**portfolioControls** | [**DmConfigPortfolioControls**](DmConfigPortfolioControls.md) |  |  [optional]
**thirdparty** | [**DmConfigThirdparty**](DmConfigThirdparty.md) |  |  [optional]



