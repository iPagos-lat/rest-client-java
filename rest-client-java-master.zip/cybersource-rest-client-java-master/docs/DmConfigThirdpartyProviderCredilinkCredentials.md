
# DmConfigThirdpartyProviderCredilinkCredentials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**sigla** | **String** |  |  [optional]



