
# PaymentsProductsPayerAuthentication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionInformation** | [**PaymentsProductsPayerAuthenticationSubscriptionInformation**](PaymentsProductsPayerAuthenticationSubscriptionInformation.md) |  |  [optional]
**configurationInformation** | [**PaymentsProductsPayerAuthenticationConfigurationInformation**](PaymentsProductsPayerAuthenticationConfigurationInformation.md) |  |  [optional]



