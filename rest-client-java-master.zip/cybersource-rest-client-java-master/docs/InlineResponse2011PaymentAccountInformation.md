
# InlineResponse2011PaymentAccountInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**card** | [**InlineResponse2011PaymentAccountInformationCard**](InlineResponse2011PaymentAccountInformationCard.md) |  |  [optional]
**features** | [**InlineResponse2011PaymentAccountInformationFeatures**](InlineResponse2011PaymentAccountInformationFeatures.md) |  |  [optional]
**network** | [**InlineResponse2011PaymentAccountInformationNetwork**](InlineResponse2011PaymentAccountInformationNetwork.md) |  |  [optional]



