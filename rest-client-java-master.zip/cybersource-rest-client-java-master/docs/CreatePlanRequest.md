
# CreatePlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientReferenceInformation** | [**Rbsv1plansClientReferenceInformation**](Rbsv1plansClientReferenceInformation.md) |  |  [optional]
**planInformation** | [**Rbsv1plansPlanInformation**](Rbsv1plansPlanInformation.md) |  |  [optional]
**orderInformation** | [**Rbsv1plansOrderInformation**](Rbsv1plansOrderInformation.md) |  |  [optional]



