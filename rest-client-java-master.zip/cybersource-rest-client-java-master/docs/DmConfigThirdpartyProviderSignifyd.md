
# DmConfigThirdpartyProviderSignifyd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**credentials** | [**DmConfigThirdpartyProviderSignifydCredentials**](DmConfigThirdpartyProviderSignifydCredentials.md) |  |  [optional]



